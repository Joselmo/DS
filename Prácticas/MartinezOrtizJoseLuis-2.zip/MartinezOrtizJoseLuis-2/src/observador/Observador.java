/**
 * 
 */
package observador;

/**
 * @author Jose-laptop
 *
 */
public interface Observador {
	
	/**
	 * M�todo para actualizar los valores del observador
	 */
	public void manejarEvento(Object valor);

}
