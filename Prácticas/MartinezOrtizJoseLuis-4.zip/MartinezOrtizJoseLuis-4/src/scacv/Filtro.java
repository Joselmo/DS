/**
 * 
 */
package scacv;

/**
 * @author Jose-laptop
 *
 */
public interface Filtro {
	
	public double ejecutar(Object o);

	public String getTipo();
	


}
