package elementos;

public enum TipoClientes {
	REGULAR, NORMAL, VIP, MAYORISTA
}
